---
title: about
layout: about
---
    计算机专业，从事嵌入式行业。
