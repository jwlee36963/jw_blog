---
title: gcc学习笔记2
index_img: /img/index/gnu_gcc.png
banner_img: /img/banner/c_program.jpg
tags:
  - GNU
  - GCC
  - C
categories:
  - gcc学习
abbrlink: d7382070
date: 2024-05-15 15:02:16
updated: 2024-05-15 15:02:16
---
待更新
